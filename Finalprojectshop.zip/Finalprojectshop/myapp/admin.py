from django.contrib import admin
from .models import Order

# 這是最標準的註冊方式
admin.site.register(Order)